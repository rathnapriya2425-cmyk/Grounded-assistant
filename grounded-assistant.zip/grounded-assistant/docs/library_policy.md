# Library Policy

The Greenfield Institute library is open from 8:30 AM to 8:00 PM on weekdays and from 9:00 AM to 2:00 PM on Saturdays. The library is closed on Sundays and on public holidays.

Undergraduate students may borrow up to four books at a time for a period of 14 days. Postgraduate students may borrow up to six books for 21 days. A borrowed book can be renewed twice, as long as no other student has reserved it.

Late returns are charged a fine of 2 rupees per book per day. If a book is lost, the student must pay the current price of the book plus a processing fee of 100 rupees. Students with unpaid fines cannot borrow new books or collect their exam hall tickets.

Silence must be maintained in the reading hall. Mobile phones should be kept on silent mode, and food and drinks are not allowed inside the library. Group discussions are allowed only in the discussion rooms on the first floor, which can be booked at the front desk for up to two hours.
