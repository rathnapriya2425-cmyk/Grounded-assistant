# Hostel Rules

Hostel residents must return to the hostel before 9:00 PM on weekdays and before 9:30 PM on weekends. A resident who needs to stay out later must submit a written permission form signed by a parent and approved by the warden at least one day in advance.

Visitors are allowed only in the visitors' lounge between 4:00 PM and 6:00 PM on Sundays. Visitors must register at the gate with a valid photo ID and may not enter the rooms.

The monthly hostel fee is 6,500 rupees and includes lodging, electricity, drinking water, and three meals a day. The fee must be paid by the 5th of every month. A late fee of 50 rupees per day is added after the due date.

Cooking appliances, heaters, and extension boards are not allowed in the rooms. Residents may keep a laptop, a phone charger, and a small desk fan. Wi-Fi is available in all rooms from 6:00 AM to 11:00 PM, and a power-saving timer switches it off at night.

Any damage to hostel property must be reported to the warden immediately. The cost of repair is shared by the residents of the room unless the person responsible is identified.
