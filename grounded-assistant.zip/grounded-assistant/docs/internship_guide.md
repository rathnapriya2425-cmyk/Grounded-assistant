# Internship Guide

Students become eligible for a credit-bearing internship from the start of the fifth semester. To be eligible, a student must have a minimum attendance of 75 percent and no active arrear in the previous two semesters.

An internship must last at least four weeks, which is 160 working hours, to earn two credits. Internships of eight weeks or more earn four credits. Remote internships are accepted if the company provides a signed offer letter that states the duration and the work area.

Before starting, the student must submit the offer letter to the Training and Placement Cell and obtain approval from a faculty mentor. Internships started without approval will not be counted for credits.

After completing the internship, the student must upload three documents within 10 days: the completion certificate, a report of 15 to 20 pages, and a feedback form signed by the company supervisor. The faculty mentor evaluates the report and awards a grade based on a 10-minute presentation.

Unpaid internships are allowed. If a company offers a stipend, the stipend belongs entirely to the student and the college does not take any share.
