"""Chunk -> embed -> retrieve. Same approach as the Task 03 project, in a small module."""
import glob
import os
import re
from dataclasses import dataclass

import numpy as np
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer

CHUNK_WORDS = 40      # start a new chunk after about this many words
MIN_SCORE = 0.20      # best chunk must be at least this similar to the question
MIN_COVERAGE = 0.6    # and contain this share of the question's content words


@dataclass
class Chunk:
    source: str
    number: int
    text: str


def split_sentences(text):
    text = re.sub(r"^#+\s*", "", text, flags=re.M)
    text = re.sub(r"\s+", " ", text).strip()
    return [s for s in re.split(r"(?<=[.!?])\s+", text) if s]


def chunk_text(text, source):
    """Whole sentences grouped into chunks; last sentence repeated as overlap."""
    chunks, current = [], []
    for sentence in split_sentences(text):
        current.append(sentence)
        if sum(len(s.split()) for s in current) >= CHUNK_WORDS:
            chunks.append(Chunk(source, len(chunks) + 1, " ".join(current)))
            current = [sentence]
    if len(current) > 1 or not chunks:
        chunks.append(Chunk(source, len(chunks) + 1, " ".join(current)))
    return chunks


def load_chunks(docs_dir):
    paths = sorted(glob.glob(os.path.join(docs_dir, "*.md")) + glob.glob(os.path.join(docs_dir, "*.txt")))
    if not paths:
        raise FileNotFoundError(f"No .md or .txt files in '{docs_dir}'")
    chunks = []
    for path in paths:
        with open(path, encoding="utf-8") as f:
            chunks += chunk_text(f.read(), os.path.basename(path))
    return chunks


# Question filler that says nothing about the topic.
FILLER = {"does", "did", "do", "happen", "happens", "item", "items", "thing", "things", "tell", "give"}


def stem(word):
    """Crude stemmer: 'includes' and 'include' -> 'includ', 'cooking' -> 'cook'."""
    if len(word) > 4:
        word = re.sub(r"(ing|ed|es|s)$", "", word)
    return word[:-1] if len(word) > 4 and word.endswith("e") else word


def stem_tokens(text):
    """Lowercase words with stop words and filler removed, then stemmed."""
    words = re.findall(r"[a-z0-9]+", text.lower())
    return [stem(w) for w in words if w not in ENGLISH_STOP_WORDS and w not in FILLER]


class Index:
    """Chunks are embedded for citation; each chunk is ranked by its best-matching sentence,
    and that sentence is the evidence used for the answer and for the coverage check."""

    def __init__(self, chunks):
        self.chunks = chunks
        self.vec = TfidfVectorizer(analyzer=stem_tokens, sublinear_tf=True)
        self.vec.fit([c.text for c in chunks])
        self.vectors = self.vec.transform([c.text for c in chunks]).toarray()
        self.sentences = [split_sentences(c.text) for c in chunks]
        self.sentence_vectors = [self.vec.transform(s).toarray() for s in self.sentences]

    def search(self, question, k=3):
        """Returns [(chunk, score, best_sentence)], best first. Score = best sentence similarity."""
        q = self.vec.transform([question]).toarray()[0]
        hits = []
        for i, chunk in enumerate(self.chunks):
            sent_scores = self.sentence_vectors[i] @ q
            j = int(np.argmax(sent_scores))
            hits.append((chunk, float(sent_scores[j]), self.sentences[i][j]))
        return sorted(hits, key=lambda h: -h[1])[:k]


def coverage(question, text):
    """Share of the question's content words that appear in the given text."""
    q_words = set(stem_tokens(question))
    return len(q_words & set(stem_tokens(text))) / len(q_words) if q_words else 0.0
