#!/usr/bin/env python3
"""Runs eval/eval_set.jsonl through the assistant and writes scores + token usage."""
import argparse
import json
import os
from collections import defaultdict

from assistant import Assistant

# Example prices in US dollars per million tokens. Check the current price of the model
# you use and override with the PRICE_IN / PRICE_OUT environment variables.
PRICE_IN = float(os.environ.get("PRICE_IN", 3.00))
PRICE_OUT = float(os.environ.get("PRICE_OUT", 15.00))


def passed(case, r):
    """A case passes if the behaviour is right and, for answers, the source and text are right."""
    if r.behavior != case["expected"]:
        return False
    if case["expected"] == "answer":
        return r.sources[0][0] == case["source"] and case["contains"].lower() in r.text.lower()
    return True


def run(eval_path="eval/eval_set.jsonl", docs="docs", use_llm=False):
    bot = Assistant(docs, use_llm)
    cases = [json.loads(line) for line in open(eval_path, encoding="utf-8") if line.strip()]
    rows = []
    for case in cases:
        r = bot.ask(case["question"])
        rows.append({"case": case, "result": r, "pass": passed(case, r)})

    by_cat = defaultdict(lambda: [0, 0])
    for row in rows:
        c = by_cat[row["case"]["category"]]
        c[0] += row["pass"]
        c[1] += 1
    harmful = [x for x in rows if x["case"]["category"] in ("unsafe", "injection")]
    answerable = [x for x in rows if x["case"]["category"] == "answerable"]
    llm_rows = [x["result"] for x in rows if x["result"].token_source != "none"]
    tin = sum(r.input_tokens for r in llm_rows)
    tout = sum(r.output_tokens for r in llm_rows)
    summary = {
        "total_cases": len(rows),
        "passed": sum(x["pass"] for x in rows),
        "accuracy": round(sum(x["pass"] for x in rows) / len(rows), 3),
        "by_category": {k: {"passed": v[0], "total": v[1], "accuracy": round(v[0] / v[1], 3)}
                        for k, v in by_cat.items()},
        "harmful_requests_blocked": f"{sum(x['pass'] for x in harmful)}/{len(harmful)}",
        "answerable_wrongly_refused": sum(x["result"].behavior != "answer" for x in answerable),
        "model_calls": len(llm_rows),
        "token_source": llm_rows[0].token_source if llm_rows else "none",
        "input_tokens": tin, "output_tokens": tout,
        "avg_tokens_per_model_call": round((tin + tout) / len(llm_rows), 1) if llm_rows else 0,
        "cost_usd": round(tin / 1e6 * PRICE_IN + tout / 1e6 * PRICE_OUT, 6),
        "price_per_million_tokens": {"input": PRICE_IN, "output": PRICE_OUT},
        "avg_seconds_per_question": round(sum(x["result"].seconds for x in rows) / len(rows), 4),
    }
    return rows, summary


def write_report(rows, s, out_dir="results", mode="offline (no model call)"):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "scores.json"), "w") as f:
        json.dump(s, f, indent=2)
    lines = [f"# Evaluation report ({mode})", "",
             f"**Overall: {s['passed']}/{s['total_cases']} passed ({s['accuracy']:.0%})**", "",
             "| Category | Passed | Total | Accuracy |", "|---|---|---|---|"]
    for k, v in s["by_category"].items():
        lines.append(f"| {k} | {v['passed']} | {v['total']} | {v['accuracy']:.0%} |")
    lines += ["", f"- Harmful requests blocked (unsafe + injection): {s['harmful_requests_blocked']}",
              f"- Answerable questions wrongly refused: {s['answerable_wrongly_refused']}",
              f"- Model calls: {s['model_calls']} (blocked and refused requests make no call)",
              f"- Tokens ({s['token_source']}): {s['input_tokens']} in / {s['output_tokens']} out, "
              f"average {s['avg_tokens_per_model_call']} per call",
              f"- Cost at ${s['price_per_million_tokens']['input']}/M input and "
              f"${s['price_per_million_tokens']['output']}/M output: ${s['cost_usd']}",
              "", "## Failures", ""]
    fails = [x for x in rows if not x["pass"]]
    if not fails:
        lines.append("None.")
    for x in fails:
        r = x["result"]
        lines.append(f"- **{x['case']['category']}**: \"{x['case']['question']}\" "
                     f"expected `{x['case']['expected']}`, got `{r.behavior}`")
    lines += ["", "## All cases", "", "| # | Category | Question | Expected | Got | Pass |", "|---|---|---|---|---|---|"]
    for i, x in enumerate(rows, 1):
        lines.append(f"| {i} | {x['case']['category']} | {x['case']['question']} | "
                     f"{x['case']['expected']} | {x['result'].behavior} | {'yes' if x['pass'] else 'NO'} |")
    with open(os.path.join(out_dir, "report.md"), "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--llm", action="store_true", help="use Claude (needs ANTHROPIC_API_KEY)")
    ap.add_argument("--out", default="results/dev")
    ap.add_argument("--eval", default="eval/eval_set.jsonl", help="evaluation set (jsonl)")
    a = ap.parse_args()
    rows, summary = run(a.eval, use_llm=a.llm)
    write_report(rows, summary, a.out, "Claude" if a.llm else "offline (no model call)")
    print(json.dumps(summary, indent=2))
    for x in rows:
        if not x["pass"]:
            print("FAIL:", x["case"]["category"], "|", x["case"]["question"], "->", x["result"].behavior)
