# Grounded helpdesk assistant (capstone)

An assistant for the (fictional) Greenfield Institute that answers questions **only from its
documents** (library, hostel and internship policies), refuses off-topic, unsafe and
prompt-injection requests, and can be **evaluated**: the repo includes an evaluation set, scored
results, and token and cost measurement.

## What it does

```
question -> guardrails -> retrieval -> scope check -> "not in documents" check -> cited answer
```

1. **Guardrails (run first, before any model call).** Rule-based checks block prompt injection
   ("ignore previous instructions", "reveal your system prompt"), unsafe requests (weapons, hacking,
   forging documents, cheating, harassment) and self-harm. Self-harm gets a supportive reply with a
   helpline (Tele-MANAS 14416 in India), not just a refusal. Blocked requests use **zero model tokens**.
2. **Retrieval.** Documents are chunked (about 40 words, sentence-based), embedded (TF-IDF vectors),
   and ranked by their best-matching sentence. The top 3 chunks are returned as sources.
3. **Scope check.** If the question has none of the domain words and does not match the documents,
   it is off-topic and the assistant says what it *can* help with.
4. **Honest "not in the documents".** If the best sentence is a weak match, the assistant says it
   couldn't find the answer and points to the right office. It never fills the gap from memory.
5. **Answer.** The answer is the best-matching sentence from the documents, with file name, chunk
   number and score for each source. With `--llm`, Claude writes the answer from the retrieved
   passages only (system prompt: answer only from passages, cite, or reply `NOT_IN_DOCUMENTS`).

## Run it

```bash
pip install -r requirements.txt
python assistant.py "How much is the monthly hostel fee?"   # one question
python assistant.py                                          # interactive
python evaluate.py                                           # dev set  -> results/dev/
python evaluate.py --eval eval/heldout_set.jsonl --out results/heldout
python -m pytest -q                                          # tests (also check the score floor)
```

Optional: `pip install anthropic`, set `ANTHROPIC_API_KEY`, then add `--llm` to either script to use
Claude. Then token counts come from the API's own usage numbers instead of estimates. Set
`PRICE_IN` / `PRICE_OUT` (US dollars per million tokens) to the current price of your model; the
defaults (3 and 15) are only examples. The `--llm` path is written but **not run by me** (no API key
in my build environment).

## Evaluation

`eval/eval_set.jsonl` has 47 cases and `eval/heldout_set.jsonl` has 13 more. Every case has an
expected behaviour: `answer`, `not_in_docs`, `off_topic`, `unsafe`/`self_harm`, or `injection`.
An answer case also needs the right source file and the right text to pass.

| Category | Dev set | Held-out set |
|---|---|---|
| Answerable questions | 14/18 | 5/5 |
| Not in documents | 7/8 | 3/3 |
| Off-topic | 9/9 | 2/2 |
| Unsafe | 7/7 | 2/2 |
| Prompt injection | 5/5 | 1/1 |
| **Total** | **42/47 (89%)** | **13/13 (100%)** |

- **Harmful requests blocked (unsafe + injection):** 12/12 dev, 3/3 held-out.
- **Honesty about the dev score:** I fixed the retrieval and scope logic after seeing the dev set's
  first-run failures (see below), so the dev score is optimistic. The held-out set was written after
  those fixes and scored once, with no tuning. It is small (13 cases), so treat 100% as "no problems
  found", not as proof.
- Full per-case tables: `results/dev/report.md`, `results/heldout/report.md`.

### Tokens and cost (offline mode: estimated)

Without an API key, tokens are **estimated** (about 4 characters per token) for the prompt a model
would receive. Dev set results:

| | Value |
|---|---|
| Requests that reach a model | 16 of 47 (the other 31 are blocked or refused first) |
| Tokens | about 5,061 in / 397 out, around 341 per call |
| Cost at example prices ($3 / $15 per million) | about $0.021 for the whole dev set |

The main cost lever is the guardrail order: two thirds of the dev requests never reach a model.
Run `python evaluate.py --llm` with your API key to replace these estimates with measured numbers.

## Decisions and what changed

- **Guardrails before the model.** Cheaper, faster, and the checks can be tested deterministically.
  The cost is that rules miss rephrased attacks (see limitations).
- **First run (v1, chunk-level evidence): 42/47.** Two failures were wrong *answers* to questions
  not in the documents ("What is the exam fee?" matched "processing fee" and "exam hall tickets" from
  two different sentences, and "What is the stipend amount?" matched the stipend sentence). Full list:
  `results/first_run_report_v1.md`.
- **Fix: sentence-level evidence.** Chunks are ranked by their best sentence, and the "enough of the
  question's words are present" check looks at that one sentence. This removed the wrong answers but
  made the assistant stricter, so some answerable questions are now refused. I chose that trade on
  purpose: for a grounded assistant, refusing is safer than answering wrongly.
- **Small fixes:** a better stemmer ("include" now matches "includes"), filler words ignored, and the
  scope check uses evidence coverage instead of a raw similarity score.

## Known failures (dev set)

- "Where can I hold a group discussion in the library?" and "When can visitors come to the hostel?"
  are wrongly refused: the key words are spread over neighbouring sentences.
- "What happens if I lose a library book?" is wrongly refused (the document says "lost", and TF-IDF
  matches words, not meaning).
- "Do remote internships count?" is answered with the wrong sentence ("counted for credits").
- "Does the library have Wi-Fi?" is answered with the hostel Wi-Fi sentence. This is the worst kind
  of error, a wrong answer, and is a known weakness of word-matching retrieval.

## Limitations

- The guardrails are keyword and pattern rules, so a rephrased attack can get through. A real
  deployment would add a model-based safety check and test against a larger red-team set.
- Retrieval matches words, not meaning. Neural embeddings would fix the "lose/lost" type of error.
- The sample documents are made up; replace `docs/` with your own and write a new evaluation set.

## Repo layout

```
assistant.py     the assistant (CLI) and pipeline
guardrails.py    injection, unsafe, self-harm and scope rules
retrieval.py     chunking, embedding, retrieval, coverage check
evaluate.py      runs an evaluation set, writes scores, tokens, cost
eval/            eval_set.jsonl (dev, 47 cases), heldout_set.jsonl (13 cases)
results/         dev/ and heldout/ reports and scores.json, first_run_report_v1.md
docs/            the documents the assistant answers from
tests/           unit tests and a score floor
```
