"""Rule-based guardrails that run BEFORE any model call (so blocked requests cost no tokens).

Order: prompt injection -> unsafe -> off-topic. Anything that passes goes to retrieval.
"""
import re

INJECTION = [
    r"ignore (all |any |the )?(previous|prior|above|earlier) (instructions|rules|prompts?)",
    r"disregard .{0,30}(instructions|rules)",
    r"(forget|ignore) (the |your )?(documents|rules|instructions)",
    r"(reveal|show|print|repeat|tell me) .{0,30}(system prompt|your instructions|your prompt)",
    r"\bsystem prompt\b",
    r"you are now\b",
    r"\bpretend (to be|you are|you're)\b",
    r"\bact as\b",
    r"\bjailbreak\b|\bdeveloper mode\b|\bDAN\b",
    r"answer from your own knowledge",
]

SELF_HARM = [
    r"\bkill myself\b", r"\bend my life\b", r"\bsuicid", r"\bwant to die\b",
    r"\bhurt myself\b", r"\bself[- ]?harm\b", r"\bdon'?t want to live\b",
]

UNSAFE = [
    r"\b(make|build|assemble|create)\b.{0,30}\b(bomb|explosive|weapon|gun)s?\b",
    r"\b(poison|stab|attack|hurt|kill)\b.{0,20}\b(someone|him|her|them|roommate|warden|teacher|student)\b",
    r"\bhack(ing)?\b", r"\bcrack\b.{0,20}\bpassword\b", r"\bsteal\b",
    r"\b(forge|forged|fake)\b.{0,30}\b(letter|certificate|id|signature|document|report)\b",
    r"\bbypass\b.{0,30}\b(attendance|biometric|security|proctor|gate|warden)\b",
    r"\bcheat(ing)?\b",
    r"\b(stalk|harass|blackmail|bully|threaten)\b",
]

# Words that mean the question is about this assistant's job (library, hostel, internships).
DOMAIN_WORDS = {
    "library", "librarian", "book", "borrow", "renew", "reading", "fine", "reserve",
    "hostel", "warden", "mess", "meal", "visitor", "wifi", "wi-fi", "roommate", "room",
    "internship", "intern", "credit", "stipend", "offer", "mentor", "attendance",
    "semester", "arrear", "certificate", "report", "placement", "fee", "fees", "visiting", "visit",
}

MESSAGES = {
    "self_harm": ("I'm really sorry you're feeling this way. I can't help with this here, but you "
                  "don't have to go through it alone. Please talk to someone you trust, or contact a "
                  "helpline such as Tele-MANAS (14416 in India) or your local emergency number."),
    "unsafe": "I can't help with that request.",
    "injection": ("I can't change my rules or share my instructions. I can answer questions about "
                  "the library, hostel and internship policies."),
    "off_topic": ("I can only help with questions about the library, hostel and internship "
                  "policies of Greenfield Institute."),
}


def _matches(patterns, text):
    return any(re.search(p, text, flags=re.I) for p in patterns)


def check_input(question):
    """Returns 'injection', 'self_harm', 'unsafe' or None (let it through)."""
    if _matches(INJECTION, question):
        return "injection"
    if _matches(SELF_HARM, question):
        return "self_harm"
    if _matches(UNSAFE, question):
        return "unsafe"
    return None


def in_scope(question, evidence_coverage):
    """In scope if it uses domain words, or most of its words appear in the best evidence sentence."""
    words = set(re.findall(r"[a-z0-9\-]+", question.lower()))
    return bool(words & DOMAIN_WORDS) or evidence_coverage >= 0.6
